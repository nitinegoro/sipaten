        <div class="box box-solid" id="sticker">
            <div class="box-header with-border">
              	<h3 class="box-title">Pengaturan Sistem</h3>
            </div>
            <div class="box-body no-padding">
              	<ul class="nav nav-pills nav-stacked">
                	<li class="<?php echo active_link_method('index', 'setting'); ?>">
                        <a href="<?php echo site_url('setting') ?>">Identitas Kecamatan</a>
                    </li>
                    <li class="<?php echo active_link_method('logo', 'setting'); ?>">
                        <a href="<?php echo site_url('setting/logo') ?>">Logo</a>
                    </li>
              	</ul>
            </div>
        </div>