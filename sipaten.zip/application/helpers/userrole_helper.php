<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Check Permission Module pada fiel role
 * Table user_role
 *
 * @param String (module name)
 * @param String (action module)
 * @return Boleaan
 **/
if( ! function_exists('is_permission') )
{
	function is_permission($param = '', $action = 'on')
	{
		$ci =& get_instance();

		
	}
}

/* End of file userrole_helper.php */
/* Location: ./application/helpers/userrole_helper.php */