<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Customer Satisfaction
 * 
 * @author Vicky Nitinegoro <pkpvicky@gmail.com>
 **/

class Satisfaction extends CI_Controller 
{
	public $data = array();

	public function __construct()
	{
		parent::__construct();

		$this->load->model('mpenilaian', 'penilaian');
		
		$this->data = array('title' => "Customer Satisfaction");	
	}

	public function index()
	{
		$this->load->view('vsatisfaction', $this->data);
	}

}

/* End of file Satisfaction.php */
/* Location: ./application/modules/satisfaction/controllers/Satisfaction.php */