<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mpenilaian extends CI_Model 
{

	public function get_answers()
	{
		return $this->db->get('opsi_jawaban')->result();
	}

	public function save()
	{
		$this->db->update('tb_options', array('option_value' => $this->input->post('pertanyaan')), array('option_name' => 'pertanyaan_penilaian'));

		if( is_array($this->input->post('jawaban')) ) 
		{
			foreach($this->input->post('jawaban') as $key => $value) 
			{
				$this->db->update('opsi_jawaban', array('jawaban' => $value), array('ID' => $key) );
			}
		}

		$config['upload_path'] = './public/image/emoji';
		$config['max_size']	= '110240';
		$config['allowed_types'] = 'gif|jpg|png|svg';
		$config['overwrite'] = FALSE;
		
		$this->upload->initialize($config);

		$result_array = array(); 

		foreach($_FILES as $key => $value)
		{
			if($this->upload->do_upload($key) != FALSE)
			{
				$ikon = $this->db->query("SELECT icon FROM opsi_jawaban WHERE ID = '{$key}'")->row('icon');
				
				@unlink("public/image/emoji/{$ikon}");

				$this->db->update('opsi_jawaban', array('icon' => $this->upload->file_name), array('ID' => $key) );
			}

		}

		$this->template->alert(
			' Perubahan tersimpan.', 
			array('type' => 'success','icon' => 'check')
		);
	}

}

/* End of file Mpenilaian.php */
/* Location: ./application/models/Mpenilaian.php */